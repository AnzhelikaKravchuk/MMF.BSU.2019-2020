﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace StringManipulation.Tests
{
    [TestFixture]
    public class GreetingTests
    {
        private static IEnumerable<TestCaseData> DataCases
        {
            get
            {
                yield return new TestCaseData("John").Returns("Hello, John!");
                yield return new TestCaseData("Alex").Returns("Hello, Alex!");
                yield return new TestCaseData("").Returns("Hello, unknown!");
            }
        }

        [TestCaseSource(nameof(DataCases))]
        public string SayHello_HelloConcatUserNameWithYield(string userName)
        {
            Console.WriteLine("You can display some debug information here, if necessary.");
            return Greeting.SayHello(userName);
        }

        [TestCase("John", ExpectedResult = "Hello, John!")]
        [TestCase("Alex", ExpectedResult = "Hello, Alex!")]
        public string SayHello_HelloConcatWithConcreteUserName(string userName) => Greeting.SayHello(userName);


        [TestCase("", ExpectedResult = "Hello, unknown!")]
        public string SayHello_HelloConcatWithEmptyString(string userName) => Greeting.SayHello(userName);

        [Test]
        public void SayHello_StringIsNull_ThrowArgumentNullException()
            => Assert.Throws<ArgumentNullException>(() => Greeting.SayHello(null),
                "Source string cannot be empty.");
    }
}