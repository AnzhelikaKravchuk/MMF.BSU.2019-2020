﻿using static System.Console;

namespace StringManipulation.Console
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            WriteLine("Enter your name: ");
            string userName = ReadLine();
            WriteLine(Greeting.SayHello(userName));
        }
    }
}