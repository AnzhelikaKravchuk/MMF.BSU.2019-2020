using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Mvc;

namespace StringManipulation.MVC.Controllers
{
    public class HelloController : Controller
    {
        [HttpGet]
        public IActionResult Hello()
        {
            return View();
        }
        
        [HttpPost]
        [ActionName("Hello")]
        public IActionResult Greetings(string userName)
        {
            return View("Greeting", Greeting.SayHello(userName));
        }
    }
}