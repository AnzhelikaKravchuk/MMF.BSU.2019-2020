﻿using static System.Console;

namespace StringManipulation.Console
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            WriteLine(Greeting.SayHello("User name"));
        }
    }
}