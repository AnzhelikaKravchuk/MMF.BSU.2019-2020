using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Mvc;

namespace StringManipulation.MVC.Controllers
{
    public class HelloController : Controller
    {
        [HttpGet]
        public IActionResult Hello()
        {
            return View();
        }

        [HttpGet]
        public IActionResult HelloReturnString(string userName)
        {
            return new ContentResult {Content = HtmlEncoder.Default.Encode(Greeting.SayHello(userName))};
            //return new ContentResult {Content = Greeting.SayHello(userName)};

        }

        [HttpPost]
        [ActionName("Hello")]
        public IActionResult Greetings(string userName)
        {
            return View("Greeting", Greeting.SayHello(userName));
        }
    }
}